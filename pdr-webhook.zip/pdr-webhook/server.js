const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ==========================================
// הגדרות - שנה אותן לפי הצרכים שלך
// ==========================================
const CONFIG = {
  PORT: process.env.PORT || 3000,
  META_VERIFY_TOKEN: process.env.META_VERIFY_TOKEN || 'pdr_meta_token_2025',
  META_APP_SECRET:   process.env.META_APP_SECRET   || '',
  WIX_SECRET:        process.env.WIX_SECRET        || 'pdr_wix_secret_2025',
  DATA_FILE: path.join(__dirname, 'leads.json'),
  NOTIFY_WEBHOOK: process.env.NOTIFY_WEBHOOK || '', // URL של WhatsApp/Slack התראות
};

// ==========================================
// פונקציות עזר
// ==========================================

function loadLeads() {
  if (!fs.existsSync(CONFIG.DATA_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(CONFIG.DATA_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveLeads(leads) {
  fs.writeFileSync(CONFIG.DATA_FILE, JSON.stringify(leads, null, 2), 'utf8');
}

function addLead(lead) {
  const leads = loadLeads();
  const newLead = {
    id: Date.now(),
    createdAt: new Date().toISOString(),
    status: 'new',
    ...lead,
  };
  leads.unshift(newLead);
  saveLeads(leads);
  console.log(`[NEW LEAD] ${lead.source} | ${lead.name} | ${lead.phone}`);
  
  // שלח התראה אם מוגדר
  if (CONFIG.NOTIFY_WEBHOOK) {
    sendNotification(newLead).catch(console.error);
  }
  
  return newLead;
}

async function sendNotification(lead) {
  try {
    const msg = `🚗 ליד PDR חדש!\nשם: ${lead.name}\nטלפון: ${lead.phone}\nמקור: ${lead.source === 'meta' ? 'Meta/פייסבוק' : 'אתר Wix'}\nרכב: ${lead.car || 'לא צויין'}\nנזק: ${lead.damage || 'לא צויין'}`;
    await fetch(CONFIG.NOTIFY_WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: msg }),
    });
  } catch (err) {
    console.error('שגיאה בשליחת התראה:', err.message);
  }
}

// ==========================================
// META WEBHOOK
// ==========================================

// אימות Webhook מול Meta (שלב ראשון)
app.get('/webhook/meta', (req, res) => {
  const mode      = req.query['hub.mode'];
  const token     = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === CONFIG.META_VERIFY_TOKEN) {
    console.log('[META] Webhook אומת בהצלחה');
    res.status(200).send(challenge);
  } else {
    console.warn('[META] אימות נכשל - verify_token לא תואם');
    res.sendStatus(403);
  }
});

// קבלת לידים מ-Meta
app.post('/webhook/meta', (req, res) => {
  // אימות חתימה (אבטחה)
  if (CONFIG.META_APP_SECRET) {
    const sig = req.headers['x-hub-signature-256'];
    const expected = 'sha256=' + crypto
      .createHmac('sha256', CONFIG.META_APP_SECRET)
      .update(JSON.stringify(req.body))
      .digest('hex');
    if (sig !== expected) {
      console.warn('[META] חתימה לא תקינה - בקשה נדחתה');
      return res.sendStatus(401);
    }
  }

  const body = req.body;
  if (body.object !== 'page') return res.sendStatus(200);

  body.entry?.forEach(entry => {
    entry.changes?.forEach(change => {
      if (change.field !== 'leadgen') return;

      const leadData = change.value;
      // leadData מכיל: leadgen_id, form_id, page_id, field_data
      const fields = {};
      leadData.field_data?.forEach(f => {
        fields[f.name] = f.values?.[0] || '';
      });

      addLead({
        source:     'meta',
        name:       fields['full_name'] || fields['שם מלא'] || '',
        phone:      fields['phone_number'] || fields['טלפון'] || '',
        email:      fields['email'] || '',
        car:        fields['car'] || fields['רכב'] || '',
        damage:     fields['damage'] || fields['נזק'] || '',
        formId:     leadData.form_id,
        leadgenId:  leadData.leadgen_id,
        rawFields:  fields,
      });
    });
  });

  res.sendStatus(200);
});

// ==========================================
// WIX WEBHOOK
// ==========================================

app.post('/webhook/wix', (req, res) => {
  // אימות Secret של Wix
  const secret = req.headers['x-wix-secret'] || req.headers['authorization'];
  if (CONFIG.WIX_SECRET && secret !== CONFIG.WIX_SECRET) {
    console.warn('[WIX] secret לא תואם');
    return res.sendStatus(401);
  }

  const body = req.body;

  // תמיכה בפורמטים שונים מ-Wix
  // פורמט 1: ישיר מ-Wix Forms
  // פורמט 2: דרך Wix Automation
  let lead = {};

  if (body.formData) {
    // Wix Forms
    const data = body.formData;
    lead = {
      source:  'wix',
      name:    data['full-name'] || data['שם מלא'] || data.name || '',
      phone:   data['phone'] || data['טלפון'] || '',
      email:   data['email'] || data['אימייל'] || '',
      car:     data['car'] || data['רכב'] || '',
      damage:  data['damage'] || data['נזק'] || data['message'] || '',
      formId:  body.formId || '',
    };
  } else {
    // פורמט ישיר / Automation
    lead = {
      source:  'wix',
      name:    body.name || body['שם מלא'] || body.fullName || '',
      phone:   body.phone || body['טלפון'] || body.phoneNumber || '',
      email:   body.email || '',
      car:     body.car  || body['רכב'] || '',
      damage:  body.damage || body['נזק'] || body.message || '',
    };
  }

  const saved = addLead(lead);
  res.status(200).json({ success: true, id: saved.id });
});

// ==========================================
// API פנימי לצפייה בלידים (לשימוש CRM)
// ==========================================

app.get('/api/leads', (req, res) => {
  const leads = loadLeads();
  const { source, status, limit = 100 } = req.query;
  
  let filtered = leads;
  if (source) filtered = filtered.filter(l => l.source === source);
  if (status) filtered = filtered.filter(l => l.status === status);
  
  res.json({
    total: filtered.length,
    leads: filtered.slice(0, parseInt(limit)),
  });
});

app.patch('/api/leads/:id', (req, res) => {
  const leads = loadLeads();
  const idx = leads.findIndex(l => l.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'ליד לא נמצא' });
  
  leads[idx] = { ...leads[idx], ...req.body, updatedAt: new Date().toISOString() };
  saveLeads(leads);
  res.json(leads[idx]);
});

// ==========================================
// בדיקת חיות
// ==========================================

app.get('/health', (req, res) => {
  const leads = loadLeads();
  res.json({
    status: 'ok',
    totalLeads: leads.length,
    meta:  leads.filter(l => l.source === 'meta').length,
    wix:   leads.filter(l => l.source === 'wix').length,
  });
});

app.listen(CONFIG.PORT, () => {
  console.log(`\n🚗 PDR Webhook Server רץ על פורט ${CONFIG.PORT}`);
  console.log(`   Meta webhook: http://localhost:${CONFIG.PORT}/webhook/meta`);
  console.log(`   Wix webhook:  http://localhost:${CONFIG.PORT}/webhook/wix`);
  console.log(`   API לידים:    http://localhost:${CONFIG.PORT}/api/leads`);
  console.log(`   Health:       http://localhost:${CONFIG.PORT}/health\n`);
});
